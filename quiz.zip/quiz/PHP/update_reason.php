<?php
include("PHP/connection.php"); // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $reason = $_POST['reason'];
    $correctAnswers = $_POST['correct_answers'];
    $userName = $_POST['user_n'];

    // Update the 'reason' column in the students_answers table
    $sql = "UPDATE students_answers SET reason = '$reason', correct_answers = $correctAnswers WHERE user_n = '$userName'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Results stored successfully!";
        // Redirect to the results page
        header("Location: results.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    // Close the database connection
    $conn->close();
}
?>
