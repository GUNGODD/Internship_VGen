
<?php
// Database connection details
// $host = "localhost";
// $user = "u595689324_milemotiveQuiz";
// $password = "u595689324_milemotiveQuiz@12345";
// $database = "u595689324_milemotiveQuiz";

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'quiz_file';

// Create a database connection
$conn = new mysqli($host, $user, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve quiz questions and options from the database
$sql = "SELECT * FROM quiz";
$result = $conn->query($sql);

// Store questions and options in an array
$quizData = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $quizData[] = $row;
    }
}

// Close the database connection
$conn->close();
?>
