<?php
$host = "localhost";
$host_user = "root";
$host_password = "";
$host_db = "quiz_file";

$conn = mysqli_connect($host, $host_user, $host_password, $host_db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submitQuiz'])) {
    
    
    // Calculate the quiz score
$quizScore = 0;
    foreach ($selectedAnswers as $question => $selectedOption) {
        
        $questionNumber = explode('_', $question)[1]; // Extract question number
        
        // Get the correct answer for the question from the quiz_answers table
        $correctAnswerQuery = "SELECT correct_answer FROM quiz_answers WHERE id = $questionNumber";
        $correctAnswerResult = mysqli_query($conn, $correctAnswerQuery);
        $correctAnswerRow = mysqli_fetch_assoc($correctAnswerResult);
        $correctAnswer = $correctAnswerRow['correct_answer'];
        
        if ($selectedOption === $correctAnswer) {
            $quizScore+=1;
        } 
    }

    
    $userName = $_SESSION['user_name'];
$updateScoreQuery = "UPDATE students_answers SET quiz_score = quiz_score + $quizScore WHERE user_n = '$userName'";
if ($conn->query($updateScoreQuery) === TRUE) {
    echo "Quiz score updated successfully!";
} else {
    echo "Error updating quiz score: " . $conn->error;
}
    // Redirect to the results page
    header("Location: results.php");
    exit();
}

mysqli_close($conn);
?>
