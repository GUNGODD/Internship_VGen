<?php

  // $host = "localhost";
  // $host_user = "u595689324_milemotiveQuiz";
  // $host_password = "u595689324_milemotiveQuiz@12345";
  // $host_db = "u595689324_milemotiveQuiz";

$host = "localhost";
$host_user = "root";
$host_password = "";
$host_db = "quiz_file";

$conn = mysqli_connect($host , $host_user, $host_password, $host_db);


?>