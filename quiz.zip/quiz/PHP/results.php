<?php
$host = "localhost";
$host_user = "root";
$host_password = "";
$host_db = "quiz_file";

$conn = mysqli_connect($host, $host_user, $host_password, $host_db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT user_n, quiz_score FROM students_answers";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Quiz Results</h1>
        <table>
            <tr>
                <th>Student Name</th>
                <th>Quiz Score</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$row['user_n']}</td>";
                echo "<td>{$row['quiz_score']}</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
