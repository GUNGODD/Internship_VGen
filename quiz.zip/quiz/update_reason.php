<?php
include('PHP/connection.php');
session_start();

if (isset($_POST['reason'])) {
    $reason = $_POST['reason'];
    $user = $_SESSION['user_name'];
    $updateQuery = "UPDATE current_loggedin_user SET Reason='$reason' WHERE Username='$user'";
    mysqli_query($conn, $updateQuery);
}
?>
