<?php 
include("PHP/connection.php");
 session_start();
?>

<?php 
include("PHP/fetch_data.php");;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    #loading {
        min-height: 100vh;
        overflow-x: hidden;
        font-family: Arial, Helvetica, sans-serif;
    }

    #submitButton {
        margin-top: 20px;
        background-color: blue;
        color: #fff;
        font-size: 20px;
        padding: 8px 10px;
        border-radius: 5px;
        border: none;
        outline: none;
        font-weight: bold;
        width: 20%;
    }

    @media screen and (max-width: 768px) {

        #previousButton,
        #nextButton,
        #submitButton {
            width: 100%;
        }
    }

    .unique-container {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        justify-content: center;
        padding: 20px;
    }

    .unique-timer {
        font-size: 28px;
        font-weight: bold;
        color: #333;
        position: fixed;
        top: 18%;
        left: 93%;
        background-color: #333;
        color: #efefef;
        padding: 10px;
        transform: translate(-50%, -50%);
        z-index: 9999;
        overflow: auto;
    }
    </style>

</head>

<body id="loading">
    <?php  
      $userprofile = $_SESSION['user_name'];
        if($userprofile == true)
        {

        }
        else 
        {
            header('location:/quiz/login.php');
        }  
?>

    <div class="container">
        <div class="navigation">
            <ul>
                <h3>Quiz Test</h3>
                <!-- <img src="IMAGES/logo2.png" alt="" style="width:60px;height:50px;margin:10px 0 20px 90px;"> -->

                <li style="margin:20px 0 50px 0;" class="active">
                    <a>
                        <span class="icon">
                            <img src="IMAGES/ideas.png" alt="">
                        </span>
                        <span class="title">Quiz</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ================== menu sectin ================ -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <img src="IMAGES/hamburger.png" alt="">
                </div>
                <div class="user">
                    <div class="profile">
                        <span class="id"><span style="font-family:cursive;"><?= $_SESSION['user_name'] ?></span>
                            <img src="IMAGES/down-arrow.png" alt="" class="profile-show">
                            <ul class="dropdown">
                                <!-- <li><a href="">Profile</a></li> -->
                                <li><a href="/quiz/logout.php">Logout</a></li>
                            </ul>
                        </span>
                    </div>
                    <img src="IMAGES/gradute-1.png" alt="" class="profile-img">
                </div>
            </div>

            <!-- loading add in this section  -->
            <div class="home-section">

                <style>
                /* CSS for modal overlay */

                /*  */
                .modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.5);
                    display: none;
                    justify-content: center;
                    align-items: center;
                    z-index: 9999;
                }

                .modal-content {
                    background-color: skyblue;
                    padding: 20px;
                    border-radius: 5px;
                    text-align: center;
                }

                .modal-content .yes,
                .modal-content .no {
                    /* background-color: rgb(2, 193, 2); */
                    color: #fff;
                    padding: 5px 10px;
                    border: none;
                    outline: none;
                    margin-top: 10px;
                }

                .modal-content .yes {
                    background-color: rgb(2, 193, 2);
                }

                .modal-content .no {
                    background-color: rgb(193, 24, 2);
                }
                </style>

                <!-- Add modal overlay HTML -->
                <div class="modal-overlay" id="modalOverlay">
                    <div class="modal-content">
                        <h2>Confirmation</h2>
                        <p>Are you sure you want to submit the data?</p>
                        <button id="yesButton" onclick="submitForm()" class="yes">Yes</button>
                        <button onclick="closeModal()" class="no">No</button>
                    </div>
                </div>

                <form id="quizForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <div class="unique-container">
                        <!-- <h1 class="unique-title">Quiz Timer</h1> -->
                        <div id="unique-timer" class="unique-timer">00:00</div>
                    </div>

                    <div id="questionContainer">
                        <!-- Display all questions and options dynamically -->
                    </div>
                    <button id="submitButton" type="button" onclick="openModal()">Submit</button>
                </form>
                <div id="thankYouMessage" style="display: none;">
                    Thank you for submitting the quiz!

                </div>

                

                <!-- //================================= -->
                <!-- Script for print quiz question and answers  -->
                <!-- //================================= -->
                <style>
                #questionContainer p {
                    font-size: 20px;
                    font-family: cursive;
                    margin: 20px 0;
                    color: #375a66;
                }

                #questionContainer label {
                    font-size: 21px;
                    padding-left: 20px;
                    font-family: cursive;
                }

                #questionContainer input[type="radio"] {
                    width: 40px;
                    height: 18px;
                }
                </style>


                <script>
                var questions = <?php echo json_encode($quizData); ?>;

                function showQuestions() {
                    
                    var questionContainer = document.getElementById('questionContainer');
                    questionContainer.innerHTML = '';

                    for (var i = 0; i < questions.length; i++) {
                        var question = questions[i];
                        var questionText = document.createElement('p');
                        var text = question.question.replace(/\\n/g, '\n').replace(/\n/g, '<br/>');
                        questionText.innerHTML = '<strong>' + text +
                            '</strong>'; // Add <strong> tags to make the text bold
                        questionContainer.appendChild(questionText);

                        for (var j = 1; j <= 4; j++) {
                            var option = question['Option_' + j];
                            var optionLabel = document.createElement('label');
                            var optionInput = document.createElement('input');
                            optionInput.type = 'radio';
                            optionInput.name = 'answer[question_' + (i + 1) + ']';
                            optionInput.value = option;
                            optionLabel.appendChild(optionInput);
                            optionLabel.appendChild(document.createTextNode(option));
                            questionContainer.appendChild(optionLabel);

                            questionContainer.appendChild(document.createElement('br'));
                        }

                        questionContainer.appendChild(document.createElement('br'));
                    }
                }

                const timerDisplay = document.getElementById('unique-timer');
                const totalTime = 3600; // Total time for the quiz in seconds
                let timeRemaining;

                function startTimer() {
                    if (localStorage.getItem('quizTime')) {
                        timeRemaining = parseInt(localStorage.getItem('quizTime'));
                    } else {
                        timeRemaining = totalTime;
                    }

                    timerInterval = setInterval(updateTimer, 1000);
                }

                function handleQuizSubmission() {
                    clearInterval(timerInterval);

                    // Send "Allotted Time is Over" to the table
                    const xhr = new XMLHttpRequest();
                    xhr.open("POST", "update_reason.php", true);
                    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            document.getElementById('quizForm').submit();
                        }
                    };
                    xhr.send("reason=Allotted Time is Over");
                }


                function updateTimer() {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;

    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');

    timerDisplay.textContent = `${formattedMinutes}:${formattedSeconds}`;

    if (timeRemaining === 0) {
        clearInterval(timerInterval);
        timerDisplay.textContent = "Time's up!";
        // Call a function to handle quiz submission or time expiration
        handleQuizSubmission();
    } else {
        timeRemaining--;
        localStorage.setItem('quizTime', timeRemaining.toString());
    }
}

function startTimer() {
    if (localStorage.getItem('quizTime')) {
        timeRemaining = parseInt(localStorage.getItem('quizTime'));
    } else {
        timeRemaining = totalTime; // Assuming you've defined totalTime somewhere
    }

    updateTimer(); // Call it once to update the display immediately

    timerInterval = setInterval(updateTimer, 1000);
}

// Call the startTimer function when the page is loaded
window.addEventListener('load', startTimer);

                function openModal() {
                    document.getElementById("modalOverlay").style.display = "flex";
                }

                function closeModal() {
                    document.getElementById("modalOverlay").style.display = "none";
                }
//1 to   // modified version   
            // submitForm  function 
            function submitForm() {
    console.log("Yes button clicked!");

    // Calculate the number of correct answers (example)
    const correctAnswers = calculateCorrectAnswers(); // Implement this function

    // Get the user's name (example)
    const userName = "John Doe"; // Replace with actual user name

    // Store the results in the students_answers table
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "update_reason.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Redirect to the results page
            window.location.href = "results.php";
        }
    };
    const data = `reason=Submitted&correct_answers=${correctAnswers}&user_n=${userName}`;
    xhr.send(data);
}



               showQuestions();
                </script> <!-- script end  -->

                <!--========================================================  -->
                <!-- Php Code for send the answers in database ---------     -->
                <!-- ==================================================== ===-->

                <?php
                  // session_start(); // Add this line to start the session

                 if ($_SERVER["REQUEST_METHOD"] == "POST") {

                    $host = "localhost";
                    $user = "root";
                    $password = "";
                    $database = "quiz_file";


                    // $host = "localhost";
                    // $user = "u595689324_milemotiveQuiz";
                    // $password = "u595689324_milemotiveQuiz@12345";
                    // $database = "u595689324_milemotiveQuiz";
 
                    // Create a database connection
                    $conn = new mysqli($host, $user, $password, $database);
                    
                     if ($conn->connect_error) {
                         die("Connection failed: " . $conn->connect_error);
                     }
                 
                     // Step 2: Retrieve the selected answers from the form submission
                     if (isset($_POST['answer'])) {
                         $selectedAnswers = $_POST['answer'];
                 
                         // Step 3: Create an array to store the column-value pairs
                         $columnValues = array();
                 
                         // Step 4: Prepare the column-value pairs for the database insertion
                         foreach ($selectedAnswers as $column => $selectedOption) {
                             $columnValues[$column] = $conn->real_escape_string($selectedOption);
                         }
                 
                         // Step 5: Insert the selected answers into the database
                         $userprofile = $_SESSION['user_name'];
                         $sql = "INSERT INTO students_answers (user_n, ";
                         $values = "VALUES ('$userprofile', ";
                 
                         foreach ($columnValues as $column => $value) {
                             $sql .= "$column, ";
                             $values .= "'$value', ";
                         }

                         // Remove the trailing commas and add closing parentheses
                         $sql = rtrim($sql, ", ") . ") ";
                         $values = rtrim($values, ", ") . ") ";
                 
                         $sql .= $values;
                         if (!$conn->query($sql)) {
                             die("Error: " . $sql . "<br>" . $conn->error);
                         }
                 
                     }
                 
                     // Step 8: Close the database connection
                     $conn->close();
                     // Step 9: Display a thank you message after submitting the quiz
                     echo '<script>
                             document.getElementById("quizForm").style.display = "none";
                             document.getElementById("thankYouMessage").style.display = "block";
                           </script>'; 

                           // Step 9: Unset and destroy the session
                       session_unset();
                       session_destroy();
                 
                       // Step 10: Redirect the user to the login page
                    //    header("Location: /quiz/login.php");
                       exit();
                     }
                   ?>

                <!-- ===============//================================= -->
                <!--                        for result  -->
                <!--============== //================================= -->
            </div>
        </div>
        <!--main end  -->
    </div>
    <!--- container end-->


    <!-- js file  -->
    <script src="JS/main.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <!--===========   change tab  ===========-->
    <script>
    // Event listener for visibility change (tab change)
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'hidden') {
            logout();
        }
    });

    // Function to handle the logout action
    function logout() {
        document.getElementById('quizForm').submit();
        setTimeout(function() {
            window.close();
        }, 100);
    }
    </script>

    <!-- ------=============  for change window ==== =---------------->
    <script>
    // Event listener for window blur (window change)
    window.addEventListener('blur', function() {
        logout();
    });

    // Function to handle the logout action
    function logout() {
        document.getElementById('quizForm').submit();
        setTimeout(function() {
            window.close();
        }, 100);
    }
    </script>

    <!-- ----=======  minimize the tab   ========== -->
    <script>
    let isLoggedIn = true;

    function logoutt() {
        isLoggedIn = false;
        console.log("Logged out");

        const xhr = new XMLHttpRequest();
        clearInterval(timerInterval);
        xhr.open("POST", "update_reason.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                document.getElementById('quizForm').submit();
            }
        };
        xhr.send("reason=Tried resizing browser");
        location.reload();
    }

    function handleResize() {
        if (window.innerWidth !== screen.width && isLoggedIn) {
            logoutt();
        }
    }

    window.addEventListener("resize", handleResize);
    </script>



</body>

</html>