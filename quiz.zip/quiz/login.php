<?php
include('PHP/connection.php');
session_start();

if (isset($_POST['login-btn'])) {
    $user = $_POST['username'];
    $pwd = $_POST['password'];
    $query = "SELECT * FROM login_table WHERE Username='$user' && Password = '$pwd' ";
    $data = mysqli_query($conn, $query);

    $check = mysqli_num_rows($data);
    if ($check == 1) {
        $checkQuery = "SELECT * FROM current_loggedin_user WHERE Username='$user'";
        $checkData = mysqli_query($conn, $checkQuery);
        $checkRows = mysqli_num_rows($checkData);

        if ($checkRows == 0) {
            // Insert the username into the table
            $insertQuery = "INSERT INTO current_loggedin_user (Username) VALUES ('$user')";
            mysqli_query($conn, $insertQuery);
            $_SESSION['user_name'] = $user;
            header('location: index.php');
            exit(); // Add an exit() statement after the header() function
        } else {
            echo "<script>alert('Contact Admin for Login Again');</script>";
        }
    } else {
        echo "<script>alert('Check Details');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Mate</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
        background-color: rgb(213, 243, 255);
        font-family: cursive;
    }
    .alert-box {
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 20px;
        width: 800px;
        margin:20px 0 0 20px;
    }

    .alert-box label {
        display: block;
        margin-bottom: 10px;
    }

    .alert-box input[type="checkbox"] {
        margin-right: 5px;
    }

    .alert-box button {
        padding: 5px 10px;
        background-color: #4CAF50;
        border: none;
        color: white;
        border-radius: 4px;
        cursor: pointer;
    }

    .alert-box button[disabled] {
        background-color: #ccc;
        cursor: not-allowed;
    }

    .read-instruction-btn {
        margin-top: 35px;
        margin-left: 49px;
        padding: 8px;
        background-color: #057ae8;
        color: #fff;
        border: none;
        outline: none;
        font-size: 18px;
        border-radius: 5px;
    }
    </style>
    <script>
    function enableButton() {
        const checkbox = document.getElementById('checkbox');
        const okButton = document.getElementById('okButton');

        okButton.disabled = !checkbox.checked;
    }

    function showAlertBox() {
        const alertBox = document.getElementById('alertBox');
        alertBox.style.display = 'block';
    }

    function closeAlertBox() {
        const alertBox = document.getElementById('alertBox');
        const lgn = document.getElementById('main-login');
        alertBox.style.display = 'none';
        lgn.style.display = 'block';
    }
    </script>
</head>

<body>
    <div id="alertBox" class="alert-box" style="display: none;">

        <p>(a) Set a specific time limit for the entire quiz or for each question.
            You have 60 minutes to complete the quiz.</p>
        <p>(b) Quiz can be based on the number of correct answers,Each correct answer will be awarded one point.
            There is no penalty for incorrect answers.</p>
        <p>(c) After the Time Limit end answers automattically save and your page will be closed. So Please complete
            your task within given time limit. </p>
        <p>(d) Quiz Page will be Closed if you referesh the page more than 2 times.</p>
        <p>(e) If you minimize the page you will be logged out from the page.</p>

        <label>
            <input type="checkbox" id="checkbox" onchange="enableButton()"> I read and understood the message
        </label>
        <button id="okButton" onclick="closeAlertBox()" disabled>OK</button>
    </div>

    <button class="read-instruction-btn" onclick="toggleAlertBox()">Read and Understand the instructions
        properly</button>

    <script>
    function toggleAlertBox() {
        var alertBox = document.getElementById("alertBox");
        if (alertBox.style.display === "none") {
            alertBox.style.display = "block";
        } else {
            alertBox.style.display = "none";
        }
    }
    </script>



    <div id="main-login" class="login" style="display: none;">

        <div class="login-form">
            <div class="form-section">
                <h2>Students Login</h2>
                <form action="" method="POST" id="login-fom" autocomplete="off">
                    <label for="">Username</label>
                    <input type="text" id="username" name="username">
                    <label for="">Password</label>
                    <input type="password" id="password" name="password">
                    <div class="check">
                        <input type="checkbox" onclick="myFunction()">Show Password
                        <a href="">Forgot password ?</a>
                    </div>
                    <button type="submit" name="login-btn" id="login-btn">Login</button>
                </form>
            </div>
        </div>
    </div>

    <!-- =====  js =========== -->
    <script src="JS/main.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const loginBtn = document.getElementById('login-btn');
        const currentHour = new Date().getHours();

        // Check if the current hour is between 14 and 15
        if (currentHour >= 0 && currentHour < 24) {
            loginBtn.disabled = false; // Enable the login button
        } else {
            alert('Can Only Login Between 15:30 and 16:30');
            loginBtn.disabled = true; // Disable the login button
        }
    });
    </script>


</body>

</html>