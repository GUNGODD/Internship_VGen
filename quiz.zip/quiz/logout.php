<?php

session_start();
// 
session_unset();
header('location:/quiz/login.php');

?>