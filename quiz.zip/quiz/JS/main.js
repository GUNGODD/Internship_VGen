// ==========  

function myFunction() {
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  let toggle = document.querySelector(".toggle");
  let navigation = document.querySelector(".navigation");
  let main = document.querySelector(".main");

  toggle.onclick = function() {
      navigation.classList.toggle("active");
      main.classList.toggle("active");
  };


  // for tab change ============

  // <!-- <script>
  // let isLoggedIn = true;

  // function logout() {
  //     isLoggedIn = false;
  //     console.log("Logged out");

  //     var xhr = new XMLHttpRequest();
  //     clearInterval(timerInterval);
  //     document.getElementById('quizForm').submit();
  //     xhr.open("GET", "logout.php", true);
  //     xhr.send();
  //     location.reload();
  // }

  // function handleVisibilityChange() {
  //     if (document.visibilityState === "hidden" && isLoggedIn) {
  //         logout();
  //     }
  // }

  // function handleResize() {
  //     if (window.innerWidth !== screen.width && isLoggedIn) {
  //         logout();
  //     }
  // }

  // document.addEventListener("visibilitychange", handleVisibilityChange);
  // window.addEventListener("resize", handleResize);
  // document.getElementById("submitButton").addEventListener("click", handleFormSubmit);
  // </script> -->
